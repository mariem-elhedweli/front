import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart-example-view',
  templateUrl: './chart-example-view.component.html',
})
export class ChartExampleViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
