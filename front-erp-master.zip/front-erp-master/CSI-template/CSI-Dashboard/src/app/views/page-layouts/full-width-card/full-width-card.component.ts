import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-width-card',
  templateUrl: './full-width-card.component.html',
  styleUrls: ['./full-width-card.component.scss']
})
export class FullWidthCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
