import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-sidebar-card',
  templateUrl: './right-sidebar-card.component.html',
  styleUrls: ['./right-sidebar-card.component.scss']
})
export class RightSidebarCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
